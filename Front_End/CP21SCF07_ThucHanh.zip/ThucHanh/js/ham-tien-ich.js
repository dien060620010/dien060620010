function tong(a, b) {
  var kq = a+b;
  return kq;
}

function tinhLapPhuong(x) {
  var kq = x*x*x;
  return kq;
}

function hienThiCauChaoMung() {
  document.write('<h1> ❤ Chào mừng ✌ </h1>');
}

function tinhLuong(lcb, heso) {
  var kq = lcb*heso*0.5;
  return kq;
}